package controller;
import java.util.ArrayList;
import java.util.List;

import model.Deck;
import model.Player;
import model.PokerCard;
import view.GameView;

public class GameController {
	public static final int MAX_PLAYERS = 5;
	private Deck deck;
	private List<Player> players;
	private Player player;
	private GameView gameView;
	private Client client;
	private boolean isStarted;
	private boolean isGameOver;
	
	public GameController(Player player) {
		this.player = player;
		players = new ArrayList<Player>(5);
		deck = new Deck();
		this.gameView = new GameView(this);
		client = new Client(this);
		isStarted = false;
	}
	
	public boolean enterNewPlayer(Player player) {
		if (players.size() < MAX_PLAYERS) {
			players.add(player);
			updateView();
			return true;
		}
		return false;
	}
	
	public Deck getDeck() {
		return deck;
	}
	
	public void setDeck(Deck deck) {
		this.deck = deck;
	}
	
	public List<Player> getPlayers() {
		return players;
	}
	
	public void setPlayers(List<Player> players) {
		this.players = players;
	}
	
	public Player getPlayer() {
		return player;
	}
	
	public Client getClient() {
		return client;
	}

	public void updateView() {
		gameView.updateView();
	}

	public void showPlayerChoice() {
		gameView.showChoice();
	}
	
	public void start() {
		isStarted = true;
		isGameOver = false;
		deck.startNewRound();
		for (Player player : players) {
			player.startNewRound();
		}
	}
	
	public boolean isStarted() {
		return isStarted;
	}
	
	public void receiveHands(PokerCard card1, PokerCard card2) {
		for (Player player : players) {
			if (player.getUserName().equals(this.player.getUserName())) {
				player.setHand(card1, card2);
			}
		}
	}
	
	/**
	 * 1. quit
	 * 2. follow
	 * 3. double
	 * 4. triple
	 * 5. quadra
	 * @param choice
	 */
	public void playerMakeChoice(int choice) {
		client.playerMakeChoice(choice);
	}
	
	public boolean isGameOver() {
		return this.isGameOver;
	}
	
	public void gameOver(String winner) {
		isGameOver = true;
		isStarted = false;
		for (Player player : players) {
			if (winner.equals(player.getUserName())) {
				player.deposit(deck.getTotal());
				gameView.updateView();
			}
		}
		gameView.showWinner(winner.equals(this.player.getUserName()));
	}
}
