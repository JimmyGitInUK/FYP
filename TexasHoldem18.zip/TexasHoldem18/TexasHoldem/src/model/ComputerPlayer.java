package model;

public class ComputerPlayer extends Player {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ComputerPlayer(String userName) {
		super(userName);
		deposit(2000);
	}

}
