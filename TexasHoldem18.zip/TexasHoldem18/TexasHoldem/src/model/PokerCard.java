package model;

import java.io.Serializable;

public class PokerCard implements Comparable<PokerCard>, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private CardRank rank;
	private CardSuit suit;
	
	public PokerCard(CardRank rank, CardSuit suit) {
		this.rank = rank;
		this.suit = suit;
	}
	
	public CardSuit getSuit() {
		return suit;
	}
	
	public CardRank getRank() {
		return rank;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj == null || !(obj instanceof PokerCard)) return false;
		return suit == ((PokerCard)obj).suit && rank == ((PokerCard)obj).rank;
	}

	@Override
	public int compareTo(PokerCard o) {
		return this.rank.getNumber() - o.rank.getNumber();
	}
	
	@Override
	public String toString() {
		return rank.getString() + " " + suit;
	}
	
}
