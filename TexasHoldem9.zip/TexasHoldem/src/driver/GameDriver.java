package driver;

import controller.GameController;
import model.Player;

public class GameDriver {
	public static void main(String[] args) {
		GameController controller = new GameController();

		Player player = new Player("Name");
		player.deposit(1000);
		Player player1 = new Player("Name1");
		player1.deposit(1000);
		Player player2 = new Player("Name2");
		player2.deposit(1000);
		Player player3 = new Player("Name3");
		player3.deposit(1000);
		Player player4 = new Player("Name4");
		player4.deposit(1000);
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				try {
					controller.enterNewPlayer(player);
					Thread.sleep(1000);
					controller.enterNewPlayer(player1);
					Thread.sleep(1000);
					controller.enterNewPlayer(player2);
					Thread.sleep(1000);
					controller.enterNewPlayer(player3);
					Thread.sleep(1000);
					controller.enterNewPlayer(player4);
					Thread.sleep(1000);
					controller.startNewRound();;
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}).start();
	}
}
