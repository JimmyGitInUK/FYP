package model;

public class Player {
	private String userName;
	private double balance;
	private PokerCard hand[];
	
	public Player(String userName) {
		this.userName = userName;
		this.hand = new PokerCard[2];
	}
	
	public void setHand(PokerCard card1, PokerCard card2) {
		this.hand[0] = card1;
		this.hand[1] = card2;
	}
	
	public PokerCard[] getHand() {
		return hand;
	}
	
	public void startNewRound() {
		hand[0] = null;
		hand[1] = null;
	}
	
	public void deposit(double amount) {
		this.balance += amount;
	}
	
	public String getUserName() {
		return userName;
	}
	
	public double getBalance() {
		return balance;
	}
}
