package model;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * write signal:
 * 	31. start new round
 */
public class Room extends Thread {
	public static final int MAX_PLAYERS = 5;
	private Deck deck;
	private List<Client> clients;
	private RoomStatus status;
	private int delay;
	private double max;
	private double total;
	
	public Room() {
		clients = new ArrayList<Client>();
		deck = new Deck();
		status = RoomStatus.Available;
		delay = 30;
		max = 50;
		total = 0;
		this.start();
	}
	
	public boolean enterNewPlayer(Client client) {
		if (clients.size() < MAX_PLAYERS) {
			sendMessage(32);
			sendMessage(client.getPlayer().getUserName());
			sendMessage(client.getPlayer().getBalance());
			clients.add(client);
			return true;
		}
		return false;
	}
	
	public List<PokerCard> getDeckCards() {
		return deck.getDeckCards();
	}
	
	public List<Client> getClients() {
		return clients;
	}
	
	public void startNewRound() {
		status = RoomStatus.Playing;
		deck.startNewRound();
		for (int i = 0; i < clients.size();) {
			try {
				clients.get(i).getWriter().writeInt(31);
				clients.get(i).getWriter().writeObject(deck.getFirstCard());
				clients.get(i).getWriter().writeObject(deck.getFirstCard());
				clients.get(i).getPlayer().bet(max);
				total += max;
				i++;
			} catch (IOException e) {
				this.clients.remove(i);
				e.printStackTrace();
				continue;
			}
		}
		deck.showFlopCards();
	}
	
	public RoomStatus getStatus() {
		return status;
	}
	
	public int getDelay() {
		return delay;
	}

	@Override
	public void run() {
		while (this.clients.size() > 0) {
			try {
				while (delay > 0) {
					try {
						Thread.sleep(1000);
						delay -= 1;
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				startNewRound();
				for (int j = 0; j < deck.getDeckCards().size(); j++) {
					sendMessage(deck.getDeckCards().get(j));
				}
				//the first bets
				for (int i = 0; i < clients.size(); i++) {
					if (clients.get(i).getPlayer().isOn()) {
						clients.get(i).getWriter().writeInt(32);
						int response = clients.get(i).getReader().readInt();
						if (response == 33) {
							double amount = clients.get(i).getReader().readDouble();
						} else if (response == 34) {
							clients.get(i).getPlayer().giveUp();
						}
					}
				}
				delay = 30;
			} catch (IOException e) {
			}
		}
	}
	
	private void sendMessage(int message) {
		for (int i = 0; i < clients.size();) {
			try {
				clients.get(i).getWriter().writeInt(message);
				i++;
			} catch (IOException e) {
				this.clients.remove(i);
				e.printStackTrace();
				continue;
			}
		}
	}
	
	private void sendMessage(Object message) {
		for (int i = 0; i < clients.size();) {
			try {
				clients.get(i).getWriter().writeObject(message);
				i++;
			} catch (IOException e) {
				this.clients.remove(i);
				e.printStackTrace();
				continue;
			}
		}
	}
	
	private void sendMessage(String message) {
		for (int i = 0; i < clients.size();) {
			try {
				clients.get(i).getWriter().writeUTF(message);
				i++;
			} catch (IOException e) {
				this.clients.remove(i);
				e.printStackTrace();
				continue;
			}
		}
	}
	
	private void sendMessage(Double message) {
		for (int i = 0; i < clients.size();) {
			try {
				clients.get(i).getWriter().writeDouble(message);
				i++;
			} catch (IOException e) {
				this.clients.remove(i);
				e.printStackTrace();
				continue;
			}
		}
	}
}
