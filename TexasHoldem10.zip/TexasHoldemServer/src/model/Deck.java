package model;
import java.util.ArrayList;
import java.util.List;

public class Deck {
	private Dealer dealer;
	private PokerCard[] flopCards;
	private PokerCard turnCard;
	private PokerCard riverCard;
	
	public Deck() {
		dealer = new Dealer();
		flopCards = new PokerCard[3];
		turnCard = null;
		riverCard = null;
	}
	
	public void startNewRound() {
		dealer.startNewRound();
		flopCards = new PokerCard[3];
		turnCard = null;
		riverCard = null;
	}
	
	public void showFlopCards() {
		for (int i = 0; i < flopCards.length; i++) {
			flopCards[i] = dealer.retrieveFirstCard();
		}
	}
	
	public PokerCard getFirstCard() {
		return dealer.retrieveFirstCard();
	}
	
	public void showTurnCard() {
		turnCard = dealer.retrieveFirstCard();
	}
	
	public void showRiverCard() {
		riverCard = dealer.retrieveFirstCard();
	}
	
	public PokerCard getTurnCard() {
		return turnCard;
	}
	
	public PokerCard getRiverCard() {
		return riverCard;
	}
	
	public List<PokerCard> getDeckCards() {
		List<PokerCard> deckCards = new ArrayList<PokerCard>();
		for (int i = 0; i < flopCards.length; i++) {
			deckCards.add(flopCards[i]);
		}
		deckCards.add(turnCard);
		deckCards.add(riverCard);
		return deckCards;
	}
}
