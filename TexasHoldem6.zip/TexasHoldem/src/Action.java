
public enum Action {
	Bet, Call, Fold, Check, Raise, Re_raise, All_in;
}
