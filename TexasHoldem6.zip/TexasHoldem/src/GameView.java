import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;

public class GameView extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final int SCREEN_WIDTH = (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
	private static final int SCREEN_HEIGHT = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();

	public GameView() {
		this.setTitle("Texas Hold'em");
		this.setExtendedState(MAXIMIZED_BOTH);
		this.setSize(new Dimension(1000, 490));
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.add(new MainPane());
		this.setVisible(true);
	}
	
	private class MainPane extends JLayeredPane {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		
		private JPanel backgroundPanel;
		
		public MainPane() {
			this.backgroundPanel = new JPanel();
			initBackgroundPane();
			this.add(backgroundPanel, Integer.valueOf(2), 0);
		}
		
		public void initBackgroundPane() {
			backgroundPanel.setBounds(0, 0, GameView.this.getWidth(), GameView.this.getHeight());
			JLabel background = new JLabel();
			Image backgroundImage = new ImageIcon("images/background.jpg").getImage();
			if (GameView.this.getExtendedState() == JFrame.MAXIMIZED_BOTH) {
				backgroundImage = backgroundImage.getScaledInstance(SCREEN_WIDTH, SCREEN_HEIGHT, Image.SCALE_FAST);
				backgroundPanel.setBounds(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
			}
			background.setIcon(new ImageIcon(backgroundImage));
			backgroundPanel.add(background);
			backgroundPanel.setOpaque(false);
		}
		
	}
	
	public static void main(String[] args) {
		new GameView();
	}
}
