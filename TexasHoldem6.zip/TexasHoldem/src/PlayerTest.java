import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class PlayerTest {

	@Test
	void testRoyalFlush() {
		Player player = new Player();
		player.setHand(new PokerCard[] {new PokerCard(CardRank.TEN, CardSuit.SPADE), 
				new PokerCard(CardRank.ACE, CardSuit.SPADE)});
		List<PokerCard> cards = new ArrayList<PokerCard>();
		cards.add(new PokerCard(CardRank.JACK, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.QUEEN, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.KING, CardSuit.SPADE));
		player.findCombo(cards);
		assertEquals(Combo.RoyalFlush, player.getCombo());
	}

	@Test
	void testStraight() {
		Player player = new Player();
		player.setHand(new PokerCard[] {new PokerCard(CardRank.TEN, CardSuit.SPADE), 
				new PokerCard(CardRank.ACE, CardSuit.SPADE)});
		List<PokerCard> cards = new ArrayList<PokerCard>();
		cards.add(new PokerCard(CardRank.JACK, CardSuit.HEART));
		cards.add(new PokerCard(CardRank.QUEEN, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.KING, CardSuit.SPADE));
		player.findCombo(cards);
		assertEquals(Combo.Straight, player.getCombo());
	}

	@Test
	void testFlush() {
		Player player = new Player();
		player.setHand(new PokerCard[] {new PokerCard(CardRank.TEN, CardSuit.SPADE), 
				new PokerCard(CardRank.ACE, CardSuit.SPADE)});
		List<PokerCard> cards = new ArrayList<PokerCard>();
		cards.add(new PokerCard(CardRank.JACK, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.QUEEN, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.NINE, CardSuit.SPADE));
		player.findCombo(cards);
		assertEquals(Combo.Flush, player.getCombo());
	}

	@Test
	void testStraightFlush() {
		Player player = new Player();
		player.setHand(new PokerCard[] {new PokerCard(CardRank.TEN, CardSuit.SPADE), 
				new PokerCard(CardRank.NINE, CardSuit.SPADE)});
		List<PokerCard> cards = new ArrayList<PokerCard>();
		cards.add(new PokerCard(CardRank.JACK, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.QUEEN, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.KING, CardSuit.SPADE));
		player.findCombo(cards);
		assertEquals(Combo.StraightFlush, player.getCombo());
	}

	@Test
	void testStraightFlush2() {
		Player player = new Player();
		player.setHand(new PokerCard[] {new PokerCard(CardRank.TWO, CardSuit.SPADE), 
				new PokerCard(CardRank.ACE, CardSuit.SPADE)});
		List<PokerCard> cards = new ArrayList<PokerCard>();
		cards.add(new PokerCard(CardRank.THREE, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.FOUR, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.FIVE, CardSuit.SPADE));
		player.findCombo(cards);
		assertEquals(Combo.StraightFlush, player.getCombo());
	}

	@Test
	void testFourOfAKind() {
		Player player = new Player();
		player.setHand(new PokerCard[] {new PokerCard(CardRank.TEN, CardSuit.SPADE), 
				new PokerCard(CardRank.ACE, CardSuit.SPADE)});
		List<PokerCard> cards = new ArrayList<PokerCard>();
		cards.add(new PokerCard(CardRank.TEN, CardSuit.HEART));
		cards.add(new PokerCard(CardRank.TEN, CardSuit.CLUB));
		cards.add(new PokerCard(CardRank.TEN, CardSuit.DIAMOND));
		player.findCombo(cards);
		assertEquals(Combo.FourOfAKind, player.getCombo());
	}

	@Test
	void testFullHouse() {
		Player player = new Player();
		player.setHand(new PokerCard[] {new PokerCard(CardRank.TEN, CardSuit.SPADE), 
				new PokerCard(CardRank.ACE, CardSuit.SPADE)});
		List<PokerCard> cards = new ArrayList<PokerCard>();
		cards.add(new PokerCard(CardRank.TEN, CardSuit.HEART));
		cards.add(new PokerCard(CardRank.ACE, CardSuit.DIAMOND));
		cards.add(new PokerCard(CardRank.ACE, CardSuit.CLUB));
		player.findCombo(cards);
		assertEquals(Combo.FullHouse, player.getCombo());
	}

	@Test
	void testThreeOfAKind() {
		Player player = new Player();
		player.setHand(new PokerCard[] {new PokerCard(CardRank.TEN, CardSuit.SPADE), 
				new PokerCard(CardRank.ACE, CardSuit.SPADE)});
		List<PokerCard> cards = new ArrayList<PokerCard>();
		cards.add(new PokerCard(CardRank.TEN, CardSuit.DIAMOND));
		cards.add(new PokerCard(CardRank.QUEEN, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.TEN, CardSuit.CLUB));
		player.findCombo(cards);
		assertEquals(Combo.ThreeOfAKind, player.getCombo());
	}

	@Test
	void testTwoPair() {
		Player player = new Player();
		player.setHand(new PokerCard[] {new PokerCard(CardRank.TEN, CardSuit.SPADE), 
				new PokerCard(CardRank.ACE, CardSuit.SPADE)});
		List<PokerCard> cards = new ArrayList<PokerCard>();
		cards.add(new PokerCard(CardRank.ACE, CardSuit.DIAMOND));
		cards.add(new PokerCard(CardRank.TEN, CardSuit.HEART));
		cards.add(new PokerCard(CardRank.NINE, CardSuit.SPADE));
		player.findCombo(cards);
		assertEquals(Combo.TwoPair, player.getCombo());
	}

	@Test
	void testOnePair() {
		Player player = new Player();
		player.setHand(new PokerCard[] {new PokerCard(CardRank.TEN, CardSuit.SPADE), 
				new PokerCard(CardRank.ACE, CardSuit.SPADE)});
		List<PokerCard> cards = new ArrayList<PokerCard>();
		cards.add(new PokerCard(CardRank.TEN, CardSuit.HEART));
		cards.add(new PokerCard(CardRank.QUEEN, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.KING, CardSuit.SPADE));
		player.findCombo(cards);
		assertEquals(Combo.OnePair, player.getCombo());
	}

	@Test
	void testHighCard() {
		Player player = new Player();
		player.setHand(new PokerCard[] {new PokerCard(CardRank.TEN, CardSuit.SPADE), 
				new PokerCard(CardRank.ACE, CardSuit.SPADE)});
		List<PokerCard> cards = new ArrayList<PokerCard>();
		cards.add(new PokerCard(CardRank.JACK, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.QUEEN, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.NINE, CardSuit.HEART));
		player.findCombo(cards);
		assertEquals(Combo.HighCard, player.getCombo());
		assertEquals(new PokerCard(CardRank.ACE, CardSuit.SPADE), player.getHighCard());
	}

}
