import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PokerCardView extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int width;
	private int height;
	private PokerCard card;
	private boolean isVisible;
	
	public PokerCardView(PokerCard card, int width, int height, boolean isVisible) {
		this.card = card;
		this.width = width;
		this.height = height;
		this.setBounds(0, 0, width, height);
		this.isVisible = isVisible;
		initPanel();
	}
	
	public void initPanel() {
		Image image = new ImageIcon("images/" + card.getSuit() + "/" + card.getRank().getNumber() + ".png").getImage();
		if (!isVisible)
			image = new ImageIcon("images/back_image.png").getImage();
		image = image.getScaledInstance(width, height, Image.SCALE_FAST);
		JLabel imageLabel = new JLabel();
		imageLabel.setBounds(0, 0, width, height);
		imageLabel.setIcon(new ImageIcon(image));
	}

}
