package model;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public enum Combo {
	RoyalFlush(9), 
	StraightFlush(8), 
	FourOfAKind(7), 
	FullHouse(6), 
	Flush(5), 
	Straight(4), 
	ThreeOfAKind(3), 
	TwoPair(2), 
	OnePair(1),
	HighCard(0);
	
	private static int[][] comboIndex = new int[][]{{0, 1, 2, 3, 4},
		{0, 1, 2, 3, 5}, {0, 1, 2, 4, 5}, {0, 1, 3, 4, 5}, 
		{0, 2, 3, 4, 5}, {1, 2, 3, 4, 5}, {0, 1, 2, 3, 6},
		{0, 1, 2, 4, 6}, {0, 1, 3, 4, 6}, {0, 2, 3, 4, 6},
		{1, 2, 3, 4, 6}, {0, 1, 2, 5, 6}, {0, 1, 3, 5, 6},
		{0, 2, 3, 5, 6}, {1, 2, 3, 5, 6}, {0, 1, 4, 5, 6},
		{0, 2, 4, 5, 6}, {1, 2, 4, 5, 6}, {0, 3, 4, 5, 6},
		{1, 3, 4, 5, 6}, {2, 3, 4, 5, 6}};
	private int priority;
	private PokerCard highCard;
	
	private Combo(int priority) {
		this.priority = priority;
	}
	
	public int getPriority() {
		return priority;
	}
	
	public PokerCard getHighCard() {
		return highCard;
	}
	
	public void setHighCard(PokerCard highCard) {
		this.highCard = highCard;
	}
	
	public static Combo findCombo(List<PokerCard> cards) {
		List<PokerCard> seven = new ArrayList<PokerCard>();
		List<PokerCard> tmp = new ArrayList<PokerCard>();
		seven.addAll(cards);
		Collections.sort(seven);
		Combo maxCombo = null;
		for (int index = 0; index < comboIndex.length; index++) {
			tmp.clear();
			for (int k = 0; k < comboIndex[index].length; k++) {
				tmp.add(seven.get(comboIndex[index][k]));
			}
			Combo combo;
			boolean isStraight = true;
			boolean isFlush = true;
			int noPairs = 0;
			int noThrees = 0;
			int noFours = 0;
			boolean pair = false;
			boolean three = false;
			CardSuit suit = tmp.get(0).getSuit();
			for (int i = 0; i < tmp.size(); i++) {
				if (tmp.get(i).getSuit() != suit)
					isFlush = false;
				if (i > 0) {
					if (tmp.get(i).getRank().getNumber() - tmp.get(i - 1).getRank().getNumber() != 1) {
						if (i == tmp.size() - 1
								&& (tmp.get(i).getRank() == CardRank.ACE && tmp.get(0).getRank() == CardRank.TWO)
								&& isStraight) {
							continue;
						}
						isStraight = false;
					} 
					if (tmp.get(i).getRank().getNumber() - tmp.get(i - 1).getRank().getNumber() == 0) {
						if (pair) {
							pair = false;
							noPairs -= 1;
							three = true;
							noThrees += 1;
						} else {
							if (three) {
								three = false;
								noThrees -= 1;
								noFours += 1;
							} else {
								pair = true;
								noPairs += 1;
							}
						}
					} else {
						pair = false;
						three = false;
					}
				}
			}
			if (isFlush) {
				if (isStraight) {
					if (tmp.get(tmp.size() - 1).getRank() == CardRank.ACE && tmp.get(0).getRank() == CardRank.TEN) {
						combo = Combo.RoyalFlush;
					} else {
						combo = Combo.StraightFlush;
					}
				} else {
					combo = Combo.Flush;
				}
			} else {
				if (isStraight)
					combo = Combo.Straight;
				else {
					if (noFours > 0)
						combo = Combo.FourOfAKind;
					else if (noThrees > 0) {
						if (noPairs > 0)
							combo = Combo.FullHouse;
						else {
							combo = Combo.ThreeOfAKind;
						}
					} else {
						if (noPairs == 2)
							combo = Combo.TwoPair;
						else if (noPairs == 1)
							combo = Combo.OnePair;
						else
							combo = Combo.HighCard;
					}
				}
			}
			combo.highCard = tmp.get(tmp.size() - 1);
			if (maxCombo == null) {
				maxCombo = combo;
			} else {
				if (combo.getPriority() > maxCombo.getPriority() 
						|| (combo.getPriority() == maxCombo.getPriority() 
						&& combo.getHighCard().getRank().getNumber() > maxCombo.getHighCard().getRank().getNumber())) {
					maxCombo = combo;
				}
			}
		}
		return maxCombo;
	}
}
