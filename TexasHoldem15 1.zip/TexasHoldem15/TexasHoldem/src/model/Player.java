package model;

import java.io.Serializable;

public class Player implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String userName;
	private double balance;
	private PokerCard hand[];
	private boolean isOn;
	
	public Player(String userName) {
		this.userName = userName;
		this.hand = new PokerCard[2];
		isOn = true;
	}
	
	public Player(String userName, double balance) {
		this.userName = userName;
		this.hand = new PokerCard[2];
		isOn = true;
		this.balance = balance;
	}
	
	public void giveUp() {
		isOn = false;
	}
	
	public boolean isOn() {
		return isOn;
	}
	
	public void setHand(PokerCard card1, PokerCard card2) {
		this.hand[0] = card1;
		this.hand[1] = card2;
	}
	
	public PokerCard[] getHand() {
		return hand;
	}
	
	public void startNewRound() {
		hand[0] = null;
		hand[1] = null;
	}
	
	public void deposit(double amount) {
		this.balance += amount;
	}
	
	public String getUserName() {
		return userName;
	}
	
	public double getBalance() {
		return balance;
	}
	
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public void bet(double amount) {
		balance -= amount;
	}
	
	public void win(double amount) {
		balance += amount;
	}
}
