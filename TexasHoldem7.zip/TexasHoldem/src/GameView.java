import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;

public class GameView extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final int SCREEN_WIDTH = (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
	private static final int SCREEN_HEIGHT = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();
	
	private GameController controller;
	private MainPane pane;
	
	public GameView() {
		controller = new GameController(this);
		this.setTitle("Texas Hold'em");
		this.setExtendedState(MAXIMIZED_BOTH);
		this.setSize(new Dimension(1000, 490));
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		pane = new MainPane();
		this.add(pane);
		this.setVisible(true);
		controller.startNewRound();
	}
	
	public void updateView() {
		pane.update();
	}
	
	private class MainPane extends JLayeredPane {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		
		private JPanel backgroundPanel;
		private JPanel cardPanel;
		
		public MainPane() {
			this.backgroundPanel = new JPanel();
			cardPanel = new JPanel();
			initBackgroundPane();
			initCardPane();
			this.add(backgroundPanel, Integer.valueOf(3), 1);
			this.add(cardPanel, Integer.valueOf(3), 0);
		}
		
		public void initBackgroundPane() {
			backgroundPanel.setBounds(0, 0, GameView.this.getWidth(), GameView.this.getHeight());
			JLabel background = new JLabel();
			Image backgroundImage = new ImageIcon("images/background.jpg").getImage();
			if (GameView.this.getExtendedState() == JFrame.MAXIMIZED_BOTH) {
				backgroundImage = backgroundImage.getScaledInstance(SCREEN_WIDTH, SCREEN_HEIGHT, Image.SCALE_FAST);
				backgroundPanel.setBounds(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
			}
			background.setIcon(new ImageIcon(backgroundImage));
			backgroundPanel.add(background);
			backgroundPanel.setOpaque(false);
		}
		
		public void initCardPane() {
			double horizontalScale = (double) GameView.this.getWidth() / 1000;
			double verticalScale = (double) GameView.this.getHeight() / 490;
			cardPanel.setBounds(0, 0, GameView.this.getWidth(), GameView.this.getHeight());
			if (GameView.this.getExtendedState() == JFrame.MAXIMIZED_BOTH) {
				cardPanel.setBounds(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
				horizontalScale = (double) SCREEN_WIDTH / 1000;
				verticalScale = (double) SCREEN_HEIGHT / 490; 
			}
			double scale = horizontalScale < verticalScale ? horizontalScale : verticalScale;
			cardPanel.setLayout(null);
			PokerCardView heap = new PokerCardView(null, (int) (85 * scale), (int) (85 / 2 * 3 * scale), false);
			heap.setLocation((int) (675 * horizontalScale), (int) (25 * verticalScale));
			cardPanel.add(heap);
			int index = 0;
			for (PokerCard card : controller.getDeckCards()) {
				if (card != null) {
					PokerCardView newCard = new PokerCardView(card, (int) (95 * scale), (int) (95 / 2 * 3 * scale), true);
					newCard.setLocation((int) (243 * horizontalScale + (newCard.getWidth() + 15) * index), (int) (184 * verticalScale));
					cardPanel.add(newCard);
					index++;
				}
			}
			cardPanel.setOpaque(false);
		}
		
		public void update() {
			cardPanel.removeAll();
			initCardPane();
			repaint();
		}
		
	}
	
	public static void main(String[] args) {
		new GameView();
	}
}
