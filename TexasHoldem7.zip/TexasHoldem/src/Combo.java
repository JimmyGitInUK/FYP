import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public enum Combo {
	RoyalFlush(9), 
	StraightFlush(8), 
	FourOfAKind(7), 
	FullHouse(6), 
	Flush(5), 
	Straight(4), 
	ThreeOfAKind(3), 
	TwoPair(2), 
	OnePair(1),
	HighCard(0);
	
	private int priority;
	private PokerCard highCard;
	
	private Combo(int priority) {
		this.priority = priority;
	}
	
	public int getPriority() {
		return priority;
	}
	
	public PokerCard getHighCard() {
		return highCard;
	}
	
	public void setHighCard(PokerCard highCard) {
		this.highCard = highCard;
	}
	
	public static Combo findCombo(List<PokerCard> cards) {
		List<PokerCard> all = new ArrayList<PokerCard>();
		all.addAll(cards);
		Collections.sort(all);
		Combo combo;
		boolean isStraight = true;
		boolean isFlush = true;
		int noPairs = 0;
		int noThrees = 0;
		int noFours = 0;
		boolean pair = false;
		boolean three = false;
		CardSuit suit = all.get(0).getSuit();
		for (int i = 0; i < all.size(); i++) {
			if (all.get(i).getSuit() != suit)
				isFlush = false;
			if (i > 0) {
				if (all.get(i).getRank().getNumber() - all.get(i - 1).getRank().getNumber() != 1) {
					if (i == all.size() - 1
							&& (all.get(i).getRank() == CardRank.ACE && all.get(0).getRank() == CardRank.TWO)
							&& isStraight) {
						continue;
					}
					isStraight = false;
				} 
				if (all.get(i).getRank().getNumber() - all.get(i - 1).getRank().getNumber() == 0) {
					if (pair) {
						pair = false;
						noPairs -= 1;
						three = true;
						noThrees += 1;
					} else {
						if (three) {
							three = false;
							noThrees -= 1;
							noFours += 1;
						} else {
							pair = true;
							noPairs += 1;
						}
					}
				} else {
					pair = false;
					three = false;
				}
			}
		}
		if (isFlush) {
			if (isStraight) {
				if (all.get(all.size() - 1).getRank() == CardRank.ACE && all.get(0).getRank() == CardRank.TEN) {
					combo = Combo.RoyalFlush;
				} else {
					combo = Combo.StraightFlush;
				}
			} else {
				combo = Combo.Flush;
			}
		} else {
			if (isStraight)
				combo = Combo.Straight;
			else {
				if (noFours > 0)
					combo = Combo.FourOfAKind;
				else if (noThrees > 0) {
					if (noPairs > 0)
						combo = Combo.FullHouse;
					else {
						combo = Combo.ThreeOfAKind;
					}
				} else {
					if (noPairs == 2)
						combo = Combo.TwoPair;
					else if (noPairs == 1)
						combo = Combo.OnePair;
					else
						combo = Combo.HighCard;
				}
			}
		}
		combo.highCard = all.get(all.size() - 1);
		return combo;
	}
}
