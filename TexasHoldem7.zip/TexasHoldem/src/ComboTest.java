import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class ComboTest {

	@Test
	void testRoyalFlush() {
		List<PokerCard> cards = new ArrayList<PokerCard>();
		cards.add(new PokerCard(CardRank.TEN, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.ACE, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.JACK, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.QUEEN, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.KING, CardSuit.SPADE));
		Combo combo = Combo.findCombo(cards);
		assertEquals(Combo.RoyalFlush, combo);
	}

	@Test
	void testStraight() {
		List<PokerCard> cards = new ArrayList<PokerCard>();
		cards.add(new PokerCard(CardRank.TEN, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.ACE, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.JACK, CardSuit.HEART));
		cards.add(new PokerCard(CardRank.QUEEN, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.KING, CardSuit.SPADE));
		Combo combo = Combo.findCombo(cards);
		assertEquals(Combo.Straight, combo);
	}

	@Test
	void testFlush() {
		List<PokerCard> cards = new ArrayList<PokerCard>();
		cards.add(new PokerCard(CardRank.TEN, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.ACE, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.JACK, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.QUEEN, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.NINE, CardSuit.SPADE));
		Combo combo = Combo.findCombo(cards);
		assertEquals(Combo.Flush, combo);
	}

	@Test
	void testStraightFlush() {
		List<PokerCard> cards = new ArrayList<PokerCard>();
		cards.add(new PokerCard(CardRank.TEN, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.NINE, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.JACK, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.QUEEN, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.KING, CardSuit.SPADE));
		Combo combo = Combo.findCombo(cards);
		assertEquals(Combo.StraightFlush, combo);
	}

	@Test
	void testStraightFlush2() {
		List<PokerCard> cards = new ArrayList<PokerCard>();
		cards.add(new PokerCard(CardRank.TWO, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.ACE, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.THREE, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.FOUR, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.FIVE, CardSuit.SPADE));
		Combo combo = Combo.findCombo(cards);
		assertEquals(Combo.StraightFlush, combo);
	}

	@Test
	void testFourOfAKind() {
		List<PokerCard> cards = new ArrayList<PokerCard>();
		cards.add(new PokerCard(CardRank.TEN, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.ACE, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.TEN, CardSuit.HEART));
		cards.add(new PokerCard(CardRank.TEN, CardSuit.CLUB));
		cards.add(new PokerCard(CardRank.TEN, CardSuit.DIAMOND));
		Combo combo = Combo.findCombo(cards);
		assertEquals(Combo.FourOfAKind, combo);
	}

	@Test
	void testFullHouse() {
		List<PokerCard> cards = new ArrayList<PokerCard>();
		cards.add(new PokerCard(CardRank.TEN, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.ACE, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.TEN, CardSuit.HEART));
		cards.add(new PokerCard(CardRank.ACE, CardSuit.DIAMOND));
		cards.add(new PokerCard(CardRank.ACE, CardSuit.CLUB));
		Combo combo = Combo.findCombo(cards);
		assertEquals(Combo.FullHouse, combo);
	}

	@Test
	void testThreeOfAKind() {
		List<PokerCard> cards = new ArrayList<PokerCard>();
		cards.add(new PokerCard(CardRank.TEN, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.ACE, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.TEN, CardSuit.DIAMOND));
		cards.add(new PokerCard(CardRank.QUEEN, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.TEN, CardSuit.CLUB));
		Combo combo = Combo.findCombo(cards);
		assertEquals(Combo.ThreeOfAKind, combo);
	}

	@Test
	void testTwoPair() {
		List<PokerCard> cards = new ArrayList<PokerCard>();
		cards.add(new PokerCard(CardRank.TEN, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.ACE, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.ACE, CardSuit.DIAMOND));
		cards.add(new PokerCard(CardRank.TEN, CardSuit.HEART));
		cards.add(new PokerCard(CardRank.NINE, CardSuit.SPADE));
		Combo combo = Combo.findCombo(cards);
		assertEquals(Combo.TwoPair, combo);
	}

	@Test
	void testOnePair() {
		List<PokerCard> cards = new ArrayList<PokerCard>();
		cards.add(new PokerCard(CardRank.TEN, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.ACE, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.TEN, CardSuit.HEART));
		cards.add(new PokerCard(CardRank.QUEEN, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.KING, CardSuit.SPADE));
		Combo combo = Combo.findCombo(cards);
		assertEquals(Combo.OnePair, combo);
	}

	@Test
	void testHighCard() {
		List<PokerCard> cards = new ArrayList<PokerCard>();
		cards.add(new PokerCard(CardRank.TEN, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.ACE, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.JACK, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.QUEEN, CardSuit.SPADE));
		cards.add(new PokerCard(CardRank.NINE, CardSuit.HEART));
		Combo combo = Combo.findCombo(cards);
		assertEquals(Combo.HighCard, combo);
		assertEquals(new PokerCard(CardRank.ACE, CardSuit.SPADE), combo.getHighCard());
	}

}
