package controller;
import java.util.ArrayList;
import java.util.List;

import model.Deck;
import model.Player;
import model.PokerCard;
import view.GameView;

public class GameController {
	public static final int MAX_PLAYERS = 5;
	private Deck deck;
	private List<Player> players;
	private GameView gameView;
	
	public GameController(GameView view) {
		this.gameView = view;
		players = new ArrayList<Player>(5);
		deck = new Deck(this);
	}
	
	public boolean enterNewPlayer(Player player) {
		if (players.size() < MAX_PLAYERS) {
			players.add(player);
			return true;
		}
		return false;
	}
	
	public List<PokerCard> getDeckCards() {
		return deck.getDeckCards();
	}
	
	public List<Player> getPlayers() {
		return players;
	}
	
	public void startNewRound() {
		deck.startNewRound();
		for (Player player : players) {
			player.startNewRound();
			player.setHand(deck.getFirstCard(), deck.getFirstCard());
		}
		deck.showFlopCards();
	}

	public void updateView() {
		gameView.updateView();
	}
}
