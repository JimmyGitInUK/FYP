package view;

import javax.swing.JPanel;

import model.Player;

public class PlayerView extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Player player;
	private int width;
	private int height;
	
	public PlayerView(Player player, int width, int height) {
		this.player = player;
		this.width = width;
		this.height = height;
		this.setBounds(0, 0, width, height);
	}
	
	public void initPanel() {
		
	}
	
}
