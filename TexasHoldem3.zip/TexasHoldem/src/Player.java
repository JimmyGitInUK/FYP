import java.util.List;

public class Player {
	private PokerCard hand[];
	private Combo combo;
	private PokerCard highCard;
	
	public Player() {
		this.hand = new PokerCard[2];
	}
	
	public void setHand(PokerCard[] hand) {
		this.hand = hand;
	}
	
	public PokerCard[] getHand() {
		return hand;
	}

	public PokerCard getCard() {
		return highCard;
	}
	
	public void findCombo(List<PokerCard> cards) {
		// TO DO
	}
}
