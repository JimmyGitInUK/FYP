
public enum CardRank {
	ACE(1, "A"), TWO(2, "2"), THREE(3, "3"),
	FOUR(4, "4"), FIVE(5, "5"), SIX(6, "6"),
	SEVEN(7, "7"), EIGHT(8, "8"), NINE(9, "9"),
	TEN(1, "10"), JACK(11, "J"), QUEEN(12, "Q"), KING(13, "K");
	private int number;
	private String string;
	
	private CardRank(int number, String string) {
		this.number = number;
		this.string = string;
	}
	
	public int getNumber() {
		return number;
	}
	
	public String getString() {
		return string;
	}
}
