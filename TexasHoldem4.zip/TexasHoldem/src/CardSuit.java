
public enum CardSuit {
	CLUB, HEART, SPADE, DIAMOND;
}
