 import java.util.ArrayList;
import java.util.List;

public class GameController {
	public static final int MAX_PLAYERS = 5;
	private Deck deck;
	private List<Player> players;
	
	public GameController() {
		players = new ArrayList<Player>(5);
		deck = new Deck();
	}
	
	public boolean enterNewPlayer(Player player) {
		if (players.size() < MAX_PLAYERS) {
			players.add(player);
			return true;
		}
		return false;
	}
}
