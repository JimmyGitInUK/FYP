package model;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Deck implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Dealer dealer;
	private PokerCard[] flopCards;
	private PokerCard turnCard;
	private PokerCard riverCard;
	private double total;
	private double max;
	
	public Deck() {
		dealer = new Dealer();
		flopCards = new PokerCard[3];
		turnCard = null;
		riverCard = null;
		max = 50;
		total = 0;
	}
	
	public void startNewRound() {
		dealer.startNewRound();
		flopCards = new PokerCard[3];
		turnCard = null;
		riverCard = null;
	}
	
	public void showFlopCards() {
		for (int i = 0; i < flopCards.length; i++) {
			flopCards[i] = dealer.retrieveFirstCard();
		}
	}
	
	public PokerCard getFirstCard() {
		return dealer.retrieveFirstCard();
	}
	
	public void showTurnCard() {
		turnCard = dealer.retrieveFirstCard();
	}
	
	public void showRiverCard() {
		riverCard = dealer.retrieveFirstCard();
	}
	
	public PokerCard getTurnCard() {
		return turnCard;
	}
	
	public PokerCard getRiverCard() {
		return riverCard;
	}
	
	public List<PokerCard> getDeckCards() {
		List<PokerCard> deckCards = new ArrayList<PokerCard>();
		for (int i = 0; i < flopCards.length; i++) {
			deckCards.add(flopCards[i]);
		}
		deckCards.add(turnCard);
		deckCards.add(riverCard);
		return deckCards;
	}
	
	public double getTotal() {
		return total;
	}
	
	public double getMax() {
		return max;
	}
	
	public void setMax(double max) {
		this.max = max;
	}
	
	public void setTotal(double total) {
		this.total = total;
	}
	
	public void bet(double amount) {
		this.total += amount;
		if (max < amount)
			max = amount;
	}
}
