import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import model.Client;
import model.Player;
import model.Room;
import model.RoomStatus;

public class Server {

	private ArrayList<Client> clients;
	private ArrayList<Room> rooms;
	private ServerSocket server;
	public Server() {
		rooms = new ArrayList<Room>();
		clients = new ArrayList<Client>();
		try {
			server = new ServerSocket(10011);
			System.out.println("Server starts");
			while (true) {
				Socket clientSocket = server.accept();
				Client client = new Client(clientSocket);
				clients.add(client);
				String name = client.getReader().readUTF();
				System.out.println(clientSocket.getInetAddress() + ": " + name + " connects to the server.");
				client.setPlayer(new Player(name, 1000));
				boolean entered = false;
				for (Room room : rooms) {
					if (room.getStatus() == RoomStatus.Available && room.getClients().size() < Room.MAX_PLAYERS) {
						room.enterNewPlayer(client);
						client.getWriter().writeInt(room.getDelay());
						client.getWriter().writeObject(room.getPlayers());
						entered = true;
						break;
					}
				}
				if (!entered) {
					Room room = new Room();
					room.enterNewPlayer(client);
					client.getWriter().writeInt(room.getDelay());
					client.getWriter().writeObject(room.getPlayers());
					rooms.add(room);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		new Server();
	}
}
