package controller;

import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Scanner;

import model.Player;
import model.PokerCard;

public class Client {
	private ObjectOutputStream writer;
	private ObjectInputStream reader;
	private GameController controller;
	private Socket socket;
	
	public Client(GameController controller) {
		this.controller = controller;
	}

//	public void playerACard(GwentCard card) {
//		try {
//			if (board.isRoundFinish()) {
//				writer.writeChar('f');
//				writer.writeInt(board.getTotalPoint());
//				writer.flush();
//			} else {
//				writer.writeChar('c');
//				writer.writeObject(card);
//			}
//			new Thread(new Runnable() {
//				
//				@Override
//				public void run() {
//					try {
//						while (reader.available() == 0) {
//							Thread.sleep(10);
//						}
//						int response = reader.readInt();
//						handleResponse(response);
//					} catch (IOException e) {
//						e.printStackTrace();
//					} catch (InterruptedException e) {
//						e.printStackTrace();
//					}
//				}
//			}).start();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//	}
	
	@SuppressWarnings("unchecked")
	public void handleResponse(int response) {
		System.out.println(response);
		try {
			switch (response) {
			case 32:
				String name = reader.readUTF();
				double balance = reader.readDouble();
				Player newPlayer = new Player(name, balance);
				controller.enterNewPlayer(newPlayer);
				break;
			
			case 31:
				controller.start();
				PokerCard card1 = (PokerCard) reader.readObject();
				PokerCard card2 = (PokerCard) reader.readObject();
				double max = reader.readDouble();
				double total = reader.readDouble();
				controller.getPlayer().setHand(card1, card2);
				controller.receiveHands(card1, card2);
				controller.getDeck().setMax(max);
				controller.getDeck().setTotal(total);
				controller.updateView();
				break;
//			
//			case 2:
//				board.setRound(false);
//				response = reader.readInt();
//				handleResponse(response);
//				break;
//			
//			case 4:
//				board.playerWins();
//				response = reader.readInt();
//				handleResponse(response);
//				break;
//			
//			case 5:
//				board.opponentWins();
//				response = reader.readInt();
//				handleResponse(response);
//				break;
//			
//			case 6:
//				board.gameOver(reader.readBoolean());
//				break;
//			
//			case 7:
//				Object object = reader.readObject();
//				if (object instanceof SpecialCard) {
//					board.opponentPlayACard((SpecialCard) object);
//				} else {
//					board.opponentPlayACard((GwentCard) object);
//				}
//				response = reader.readInt();
//				handleResponse(response);
//				break;
//
//			case 8:
//				board.roundOver();
//				new Thread(new Runnable() {
//					
//					@Override
//					public void run() {
//						int isMyRound;
//						try {
//							isMyRound = reader.readInt();
//							board.startNewRound();
//							handleResponse(isMyRound);
//						} catch (IOException e) {
//							e.printStackTrace();
//						}
//					}
//				}).start();
//				break;
//				
			default:
				int delay = response;
				try {
					List<Player> players = (List<Player>) reader.readObject();
					for (Player player : players) {
						controller.enterNewPlayer(player);
					}
					controller.updateView();
					System.out.println(delay);
				} catch (IOException e) {
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
				break;
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
	}

	public void ready() {
		try {
			String ip = "127.0.0.1";
			int port = 10011;
			File file = new File("config/server.ip");
			if (file.exists()) {
				Scanner ipReader = new Scanner(file);
				if (ipReader.hasNextLine()) {
					ip = ipReader.nextLine();
				}
				ipReader.close();
			}
			socket = new Socket(ip, port);
			writer = new ObjectOutputStream(socket.getOutputStream());
			reader = new ObjectInputStream(socket.getInputStream());
			writer.writeUTF(controller.getPlayer().getUserName());
			writer.flush();
			Thread readerThread = new Thread(new Runnable() {
				
				@Override
				public void run() {
					while (true) {
						try {
							int response = reader.readInt();
							handleResponse(response);
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
			});
			readerThread.start();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void gameOver() {
		try {
			socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
