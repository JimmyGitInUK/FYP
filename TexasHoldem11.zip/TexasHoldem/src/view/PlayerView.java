package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.text.DecimalFormat;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

import model.Player;

public class PlayerView extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Player player;
	private int width;
	private int height;
	private JPanel profilePanel;
	private JPanel handsPanel;
	private boolean showHands;
	private boolean isStarted;
	
	public PlayerView(Player player, int width, int height, boolean showHands, boolean isStarted) {
		this.player = player;
		this.width = width;
		this.height = height;
		this.showHands = showHands;
		this.isStarted = isStarted;
		this.setBounds(0, 0, width, height);
		this.profilePanel = new JPanel();
		this.handsPanel = new JPanel();
		initPanel();
	}
	
	public void initPanel() {
		this.profilePanel.setPreferredSize(new Dimension(width, height / 4));
		this.handsPanel.setPreferredSize(new Dimension(width, height / 4 * 3));
		this.handsPanel.setLayout(null);
		//initialize profile panel
		Image image = new ImageIcon("images/photo.png").getImage();
		image = image.getScaledInstance((int) (height / 4 * 0.73), height / 4, Image.SCALE_FAST);
		JLabel photo = new JLabel();
		photo.setIcon(new ImageIcon(image));
		JLabel name = new JLabel(player.getUserName());
		name.setForeground(Color.white);
		JLabel balance = new JLabel("$ " + new DecimalFormat("0.##").format(player.getBalance()));
		balance.setForeground(Color.white);
		profilePanel.add(photo, BorderLayout.WEST);
		profilePanel.add(name, BorderLayout.CENTER);
		profilePanel.add(balance, BorderLayout.EAST);
		profilePanel.setOpaque(false);
		
		for (int i = 0; i < player.getHand().length; i++) {
			if (player.getHand()[i] != null || isStarted) {
				PokerCardView newCard = new PokerCardView(null, width / 2 - 5, (int) ((width / 2 - 5) / 2 * 3), false);
				if (showHands)
					newCard = new PokerCardView(player.getHand()[i], width / 2 - 5, (int) ((width / 2 - 5) / 2 * 3), true);
				newCard.setLocation(5 + i * width / 2, 0);
				handsPanel.add(newCard);
			}
		}
		handsPanel.setOpaque(false);
		this.add(profilePanel,  BorderLayout.NORTH);
		this.add(handsPanel, BorderLayout.CENTER);
		this.setOpaque(false);
	}
	
}
