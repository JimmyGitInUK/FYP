package view;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;

import controller.GameController;
import model.PokerCard;

public class GameView extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final int SCREEN_WIDTH = (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
	private static final int SCREEN_HEIGHT = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();
	
	private GameController controller;
	private MainPane pane;
	
	public GameView(GameController controller) {
		this.controller = controller;
		this.setTitle("Texas Hold'em");
		this.setExtendedState(MAXIMIZED_BOTH);
		this.setSize(new Dimension(1000, 490));
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		pane = new MainPane();
		this.add(pane);
		this.setVisible(true);
	}
	
	public void updateView() {
		pane.update();
	}
	
	private class MainPane extends JLayeredPane {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		
		private JPanel backgroundPanel;
		private JPanel cardPanel;
		private JPanel playerPanel;
		private JPanel counterPanel;
		
		public MainPane() {
			this.backgroundPanel = new JPanel();
			this.cardPanel = new JPanel();
			this.playerPanel = new JPanel();
			this.counterPanel = new JPanel();
			initBackgroundPane();
			initCardPane();
			initPlayerPanel();
			initCounterPanel();
			this.add(backgroundPanel);
			this.add(playerPanel);
			this.add(cardPanel);
			this.add(counterPanel);
			this.setLayer(backgroundPanel,  -1);
			this.setLayer(playerPanel, 0);
			this.setLayer(cardPanel, 1);
			this.setLayer(counterPanel, 2);
		}
		
		private void initCounterPanel() {
			double horizontalScale = (double) GameView.this.getWidth() / 1000;
			double verticalScale = (double) GameView.this.getHeight() / 490;
			counterPanel.setBounds(0, 0, GameView.this.getWidth(), GameView.this.getHeight());
			if (GameView.this.getExtendedState() == JFrame.MAXIMIZED_BOTH) {
				counterPanel.setBounds(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
				horizontalScale = (double) SCREEN_WIDTH / 1000;
				verticalScale = (double) SCREEN_HEIGHT / 490; 
			}
			double scale = horizontalScale < verticalScale ? horizontalScale : verticalScale;
			JLabel counterJLabel = new JLabel();
			counterJLabel.setForeground(Color.white);
			counterJLabel.setFont(new Font("Consolas", Font.BOLD, (int)(scale * 30)));
			counterJLabel.setText("<html>Minimum bet: " + controller.getDeck().getMax() + "<br />Total chips: " + controller.getDeck().getTotal() + "</html>");
			counterPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 100, (int) (80 * verticalScale)));
			counterPanel.add(counterJLabel);
			counterPanel.setOpaque(false);
		}

		private void initPlayerPanel() {
			double horizontalScale = (double) GameView.this.getWidth() / 1000;
			double verticalScale = (double) GameView.this.getHeight() / 490;
			playerPanel.setBounds(0, 0, GameView.this.getWidth(), GameView.this.getHeight());
			if (GameView.this.getExtendedState() == JFrame.MAXIMIZED_BOTH) {
				playerPanel.setBounds(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
				horizontalScale = (double) SCREEN_WIDTH / 1000;
				verticalScale = (double) SCREEN_HEIGHT / 490; 
			}
			double scale = horizontalScale < verticalScale ? horizontalScale : verticalScale;
			playerPanel.setLayout(null);
			for (int i = 0; i < controller.getPlayers().size(); i++) {
				System.out.println(i);
				PlayerView playerView = new PlayerView(controller.getPlayers().get(i), 
						(int) (120 * scale), 
						(int) (130 * scale), 
						controller.getPlayers().get(i).getUserName().equals(controller.getPlayer().getUserName()), 
						controller.isStarted());
				if (i == 0 || i == 4)
					playerView.setLocation(i == 0 ? 0 : (int) (875 * horizontalScale), (int) (190 * verticalScale));
				else {
					playerView.setLocation((int) ((175 + (i - 1) * 260) * horizontalScale), (int) (360 * verticalScale));
				}
				playerPanel.add(playerView);
			}
			playerPanel.setOpaque(false);
		}

		private void initBackgroundPane() {
			backgroundPanel.setBounds(0, 0, GameView.this.getWidth(), GameView.this.getHeight());
			JLabel background = new JLabel();
			Image backgroundImage = new ImageIcon("images/background.jpg").getImage();
			if (GameView.this.getExtendedState() == JFrame.MAXIMIZED_BOTH) {
				backgroundImage = backgroundImage.getScaledInstance(SCREEN_WIDTH, SCREEN_HEIGHT, Image.SCALE_FAST);
				backgroundPanel.setBounds(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
			}
			background.setIcon(new ImageIcon(backgroundImage));
			backgroundPanel.add(background);
			backgroundPanel.setOpaque(false);
		}
		
		private void initCardPane() {
			double horizontalScale = (double) GameView.this.getWidth() / 1000;
			double verticalScale = (double) GameView.this.getHeight() / 490;
			cardPanel.setBounds(0, 0, GameView.this.getWidth(), GameView.this.getHeight());
			if (GameView.this.getExtendedState() == JFrame.MAXIMIZED_BOTH) {
				cardPanel.setBounds(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
				horizontalScale = (double) SCREEN_WIDTH / 1000;
				verticalScale = (double) SCREEN_HEIGHT / 490; 
			}
			double scale = horizontalScale < verticalScale ? horizontalScale : verticalScale;
			cardPanel.setLayout(null);
			PokerCardView heap = new PokerCardView(null, (int) (85 * scale), (int) (85 / 2 * 3 * scale), false);
			heap.setLocation((int) (675 * horizontalScale), (int) (25 * verticalScale));
			cardPanel.add(heap);
			int index = 0;
			for (PokerCard card : controller.getDeck().getDeckCards()) {
				if (card != null) {
					PokerCardView newCard = new PokerCardView(card, (int) (95 * scale), (int) (95 / 2 * 3 * scale), true);
					newCard.setLocation((int) (243 * horizontalScale + (newCard.getWidth() + 15) * index), (int) (184 * verticalScale));
					cardPanel.add(newCard);
					index++;
				}
			}
			cardPanel.setOpaque(false);
		}
		
		public void update() {
			cardPanel.removeAll();
			initCardPane();
			playerPanel.removeAll();
			initPlayerPanel();
			counterPanel.removeAll();
			initCounterPanel();
			repaint();
			revalidate();
		}
		
	}
}
