import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Player {
	private PokerCard hand[];
	private Combo combo;
	private PokerCard highCard;
	
	public Player() {
		this.hand = new PokerCard[2];
	}
	
	public void setHand(PokerCard[] hand) {
		this.hand = hand;
	}
	
	public PokerCard[] getHand() {
		return hand;
	}

	public PokerCard getHighCard() {
		return highCard;
	}
	
	public Combo getCombo() {
		return combo;
	}
	
	public void findCombo(List<PokerCard> cards) {
		List<PokerCard> all = new ArrayList<PokerCard>();
		all.addAll(cards);
		all.add(hand[0]);
		all.add(hand[1]);
		Collections.sort(all);
		boolean isStraight = true;
		boolean isFlush = true;
		int noPairs = 0;
		int noThrees = 0;
		int noFours = 0;
		boolean pair = false;
		boolean three = false;
		highCard = all.get(all.size() - 1);
		CardSuit suit = all.get(0).getSuit();
		for (int i = 0; i < all.size(); i++) {
//			System.out.println(all.get(i));
			if (all.get(i).getSuit() != suit)
				isFlush = false;
			if (i > 0) {
				if (all.get(i).getRank().getNumber() - all.get(i - 1).getRank().getNumber() != 1) {
					if (i == all.size() - 1
							&& (all.get(i).getRank() == CardRank.ACE && all.get(0).getRank() == CardRank.TWO)
							&& isStraight) {
						continue;
					}
					isStraight = false;
				} 
				if (all.get(i).getRank().getNumber() - all.get(i - 1).getRank().getNumber() == 0) {
					if (pair) {
						pair = false;
						noPairs -= 1;
						three = true;
						noThrees += 1;
					} else {
						if (three) {
							three = false;
							noThrees -= 1;
							noFours += 1;
						} else {
							pair = true;
							noPairs += 1;
						}
					}
				} else {
					pair = false;
					three = false;
				}
			}
		}
		if (isFlush) {
			if (isStraight) {
				if (highCard.getRank() == CardRank.ACE && all.get(0).getRank() == CardRank.TEN) {
					this.combo = Combo.RoyalFlush;
				} else {
					this.combo = Combo.StraightFlush;
				}
			} else {
				this.combo = Combo.Flush;
			}
		} else {
			if (isStraight)
				this.combo = Combo.Straight;
			else {
				if (noFours > 0)
					this.combo = Combo.FourOfAKind;
				else if (noThrees > 0) {
					if (noPairs > 0)
						this.combo = Combo.FullHouse;
					else {
						this.combo = Combo.ThreeOfAKind;
					}
				} else {
					if (noPairs == 2)
						this.combo = Combo.TwoPair;
					else if (noPairs == 1)
						this.combo = Combo.OnePair;
					else
						this.combo = Combo.HighCard;
				}
			}
		}
	}
}
