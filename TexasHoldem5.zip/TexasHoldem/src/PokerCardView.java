import javax.swing.JPanel;

public class PokerCardView extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int width;
	private int height;
	
	public PokerCardView(int width, int height) {
		
	}

}
