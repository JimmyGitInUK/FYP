
public enum Combo {
	RoyalFlush(9), 
	StraightFlush(8), 
	FourOfAKind(7), 
	FullHouse(6), 
	Flush(5), 
	Straight(4), 
	ThreeOfAKind(3), 
	TwoPair(2), 
	OnePair(1), 
	HighCard(0);
	
	private int priority;
	
	private Combo(int priority) {
		this.priority = priority;
	}
	
	public int getPriority() {
		return priority;
	}
}
