
public class Player {
	private PokerCard hand[];
	
	public Player() {
		this.hand = new PokerCard[2];
	}
	
	public void setHand(PokerCard[] hand) {
		this.hand = hand;
	}
	
	public PokerCard[] getHand() {
		return hand;
	}
}
