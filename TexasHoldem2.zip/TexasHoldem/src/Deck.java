import java.util.ArrayList;
import java.util.List;

public class Deck {
	private Dealer dealer;
	private List<PokerCard> deckCards;
	
	public Deck() {
		dealer = new Dealer();
		deckCards = new ArrayList<PokerCard>();
	}
	
	public void startNewRound() {
		dealer.startNewRound();
		deckCards.clear();
	}
	
	public void showMoreOneCard() {
		deckCards.add(dealer.retrieveFirstCard());
	}
	
	public List<PokerCard> getDeckCards() {
		return deckCards;
	}
}
