package model;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Dealer implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<PokerCard> cards;
	
	public Dealer() {
		cards = new ArrayList<PokerCard>();
		initCards();
	}
	
	public void initCards() {
		cards.clear();
		for (int i = 0; i < CardSuit.values().length; i++) {
			for (int j = 0; j < CardRank.values().length; j++) {
				cards.add(new PokerCard(CardRank.values()[j], CardSuit.values()[i]));
			}
		}
	}
	
	public void startNewRound() {
		initCards();
		Collections.shuffle(cards);
	}
	
	public PokerCard retrieveFirstCard() {
		return cards.remove(0);
	}
}
