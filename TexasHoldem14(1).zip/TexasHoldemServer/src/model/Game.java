package model;

public class Game {
	public static void main(String[] args) {
		
	}
}
