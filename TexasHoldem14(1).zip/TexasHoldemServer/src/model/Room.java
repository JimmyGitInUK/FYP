package model;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * write signal:
 * 	31. start new round
 *  32. first bet
 *  1. response: player choose quit
 *  2. response: player choose follow
 *  3. response: player choose double
 *  4. response: player choose triple
 *  5. response: player choose quadra
 *  35. send the current deck
 *  36. enter a new player
 *  37. send the current player
 *  38. notify others that one player give up
 */
public class Room extends Thread {
	public static final int MAX_PLAYERS = 5;
	private Deck deck;
	private List<Client> clients;
	private RoomStatus status;
	private int delay;
	
	public Room() {
		clients = new ArrayList<Client>();
		deck = new Deck();
		status = RoomStatus.Available;
		delay = 30;
		this.start();
	}
	
	public boolean enterNewPlayer(Client client) {
		if (clients.size() < MAX_PLAYERS) {
			sendMessage(36);
			sendMessage(client.getPlayer().getUserName());
			sendMessage(client.getPlayer().getBalance());
			clients.add(client);
			return true;
		}
		return false;
	}
	
	public List<PokerCard> getDeckCards() {
		return deck.getDeckCards();
	}
	
	public List<Client> getClients() {
		return clients;
	}
	
	public List<Player> getPlayers() {
		List<Player> players = new ArrayList<>();
		for (Client client : clients) {
			players.add(client.getPlayer());
		}
		return players;
	}
	
	public void startNewRound() {
		status = RoomStatus.Playing;
		deck.startNewRound();
		for (int i = 0; i < clients.size();) {
			try {
				clients.get(i).getWriter().writeInt(31);
				clients.get(i).getWriter().writeObject(deck.getFirstCard());
				clients.get(i).getWriter().writeObject(deck.getFirstCard());
				clients.get(i).getWriter().flush();
				clients.get(i).getPlayer().bet(deck.getMax());
				deck.bet(deck.getMax());
				i++;
			} catch (IOException e) {
				this.clients.remove(i);
				e.printStackTrace();
				continue;
			}
		}
		sendMessage(deck.getMax());
		sendMessage(deck.getTotal());
	}
	
	public RoomStatus getStatus() {
		return status;
	}
	
	public int getDelay() {
		return delay;
	}

	@Override
	public void run() {
		while (this.clients.size() > 0) {
			try {
				while (delay > 0) {
					try {
						Thread.sleep(1000);
						delay -= 1;
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				startNewRound();
				for (Player player : getPlayers()) {
					sendMessage(37);
					sendMessage(player.getUserName());
					sendMessage(player.getBalance());
				}
				//there are four turns to bet in total
				for (int turn = 0; turn < 4; turn++) {
					if (turn == 1) {
						deck.showFlopCards();
						sendMessage(35);
						sendMessage(deck);
					} else if (turn == 2) {
						deck.showTurnCard();
						sendMessage(35);
						sendMessage(deck);
					} else if (turn == 3) {
						deck.showRiverCard();
						sendMessage(35);
						sendMessage(deck);
					}
					for (int i = 0; i < clients.size(); i++) {
						if (clients.get(i).getPlayer().isOn()) {
							clients.get(i).getWriter().writeInt(32);
							clients.get(i).getWriter().flush();
							int response = clients.get(i).getReader().readInt();
							if (response >= 2 && response <= 5) {
								double amount = clients.get(i).getReader().readDouble();
								clients.get(i).getPlayer().bet(amount);
								deck.bet(amount);
								sendMessage(37);
								sendMessage(clients.get(i).getPlayer().getUserName());
								sendMessage(clients.get(i).getPlayer().getBalance());
							} else if (response == 1) {
								clients.get(i).getPlayer().giveUp();
								sendMessage(38);
								sendMessage(clients.get(i).getPlayer().getUserName());
							}
							sendMessage(35);
							System.out.println(deck.getMax() + " " + deck.getTotal());
							sendMessage(deck);
						}
					}
				}
				delay = 30;
			} catch (IOException e) {
			}
		}
	}
	
	private void sendMessage(int message) {
		for (int i = 0; i < clients.size();) {
			try {
				clients.get(i).getWriter().writeInt(message);
				clients.get(i).getWriter().flush();
				clients.get(i).getWriter().reset();
				i++;
			} catch (IOException e) {
				this.clients.remove(i);
				e.printStackTrace();
				continue;
			}
		}
	}
	
	private void sendMessage(Object message) {
		for (int i = 0; i < clients.size();) {
			try {
				clients.get(i).getWriter().writeObject(message);
				clients.get(i).getWriter().flush();
				clients.get(i).getWriter().reset();
				i++;
			} catch (IOException e) {
				this.clients.remove(i);
				e.printStackTrace();
				continue;
			}
		}
	}
	
	private void sendMessage(String message) {
		for (int i = 0; i < clients.size();) {
			try {
				clients.get(i).getWriter().writeUTF(message);
				clients.get(i).getWriter().flush();
				clients.get(i).getWriter().reset();
				i++;
			} catch (IOException e) {
				this.clients.remove(i);
				e.printStackTrace();
				continue;
			}
		}
	}
	
	private void sendMessage(Double message) {
		for (int i = 0; i < clients.size();) {
			try {
				clients.get(i).getWriter().writeDouble(message);
				clients.get(i).getWriter().flush();
				clients.get(i).getWriter().reset();
				i++;
			} catch (IOException e) {
				this.clients.remove(i);
				e.printStackTrace();
				continue;
			}
		}
	}
}
