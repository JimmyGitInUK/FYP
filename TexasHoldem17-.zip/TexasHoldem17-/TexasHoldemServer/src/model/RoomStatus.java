package model;

public enum RoomStatus {
	Playing, Available;
}
