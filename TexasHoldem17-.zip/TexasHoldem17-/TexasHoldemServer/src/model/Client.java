package model;


import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class Client {
	private ObjectInputStream reader;
	private ObjectOutputStream writer;
	private Player player;
	
	public Client(Socket clientSocket) {
		if (clientSocket!= null) {
			try {
				reader = new ObjectInputStream(clientSocket.getInputStream());
				writer = new ObjectOutputStream(clientSocket.getOutputStream());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public ObjectInputStream getReader() {
		return reader;
	}
	
	public ObjectOutputStream getWriter() {
		return writer;
	}
	
	public void setPlayer(Player player) {
		this.player = player;
	}
	
	public Player getPlayer() {
		return player;
	}
}
